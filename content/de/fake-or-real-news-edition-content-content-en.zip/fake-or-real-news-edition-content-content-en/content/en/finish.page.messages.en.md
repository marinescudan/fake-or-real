---
uuid: f4938728-4b21-47a1-819b-7d505b2e062c
locale: en
locale_for_humans: "English"
contentType: "app_interface"
slug: "localisation"
published: true
project: "for"
page: "finish"
keys:
    finish_goodbye_title: "Thanks"
    finish_cta_go_start: "Go to start"
    finish_image_left_url: "https://cdn.ttc.io/s/fake-or-real-app/nikoline_nik_-8694.jpg"
    finish_image_center_url: "https://cdn.ttc.io/s/fake-or-real-app/misinfo_logo.jpg"
    finish_image_right_url: "https://cdn.ttc.io/s/fake-or-real-app/nikoline_nik_-7168.jpg"
---
<p style="text-align: center;">## It's been brief but **special**

For more info, check out this link in the Data Detox Kit chapter on Misinformation
[https://datadetoxkit.org/en/wellbeing/misinformation](https://datadetoxkit.org/en/wellbeing/misinformation)</p>