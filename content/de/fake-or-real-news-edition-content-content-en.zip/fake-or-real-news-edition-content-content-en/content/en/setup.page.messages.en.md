---
uuid: f4938728-4b21-47a1-819b-7d505b2e062c
locale: en
locale_for_humans: "English"
contentType: "app_interface"
slug: "localisation"
published: true
project: "for"
page: "setup"
keys:
    setup_choose_language: "Set quiz language"
    setup_start_quiz: "Start quiz"
---
Setup text is not displayed in the app yet.