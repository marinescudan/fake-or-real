---
uuid: 857b5602-a777-11e5-bf7f-feff819cdc9f
locale: en
date: 2016-03-12T00:00:00.000Z
published: false
project: "for"
slug: "question"
title: "Exemple 1"
question_title: "Which of these items are spreading fake news about Coronoavirus?"
question_subtitle: ""
question_submit_message_heading: "Chose every item you think it fasle or misleading"
question_submit_message_correct: "Correct"
question_submit_message_wrong: "Wrong"
question_single_result_message_real: "It is real"
question_single_result_message_fake: "It is fake"
question_cta_go_explanation: "Check"
question_cta_help: "Choose between 1 and 4 of the options above!"
question_cta_fake: "Fake?"
question_cta_real: "Real?"
explanation_title: "Three of these items are fake or misleading"
explanation_subtitle: ""
explanation_cta_go_stats: "See what other people thought"
stats_title: "Find the fake adverts"
stats_subtitle: "Other people decided that these adverts are not trustworthy"
stats_cta_go_again: "Next Question"
stats_cta_go_finish: "Restart Game"
items:
  - fake: true
    question_media_url: "https://cdn.ttc.io/s/fake-or-real-app/corona1.jpg"
    explanation_media_url: "https://cdn.ttc.io/s/fake-or-real-app/corona1.jpg"
    stats_media_url: "https://cdn.ttc.io/s/fake-or-real-app/corona1.jpg"
    question_title: ""
    question_text: "Meme on coronavirus as intentional Chinese bioweapon"
    explanation_title: ""
    stats_title: ""
    click_count: 0
  - fake: false
    question_media_url: "https://cdn.ttc.io/s/fake-or-real-app/corona2.jpg"
    explanation_media_url: "https://cdn.ttc.io/s/fake-or-real-app/corona2.jpg"
    stats_media_url: "https://cdn.ttc.io/s/fake-or-real-app/corona2.jpg"
    question_title: ""
    question_text: "News article about Coronavirus and blood plasma"
    explanation_title: ""
    stats_title: ""
    click_count: 0
  - fake: true
    question_media_url: "https://cdn.ttc.io/s/fake-or-real-app/corona3.jpg"
    explanation_media_url: "https://cdn.ttc.io/s/fake-or-real-app/corona3.jpg"
    stats_media_url: "https://cdn.ttc.io/s/fake-or-real-app/corona3.jpg"
    question_title: ""
    question_text: "Google search autofill with popular Coronavirus search terms"
    explanation_title: ""
    stats_title: ""
    click_count: 0
  - fake: true
    question_media_url: "https://cdn.ttc.io/s/fake-or-real-app/corona4.jpg"
    explanation_media_url: "https://cdn.ttc.io/s/fake-or-real-app/corona4.jpg"
    stats_media_url: "https://cdn.ttc.io/s/fake-or-real-app/corona4.jpg"
    question_title: ""
    question_text: "Facebook post on 5G and Bill Gates"
    explanation_title: ""
    stats_title: ""
    click_count: 0
---
### The news story on blood plasma is genuine.

The autofill feature of Google’s search box shows popular searches and automatically leads people particular topics – in this case that the coronavirus is a bioweapon. This feature encourages people to search for the topic or keyword, in turn boosting its position in search results and making the story seem more likely to be true.

Memes are also effective carriers of misinformation, because they are seen as lighthearted and their humour is often given more importance than their meaning. Plus, they are highly shareable, which means they circulate faster.
