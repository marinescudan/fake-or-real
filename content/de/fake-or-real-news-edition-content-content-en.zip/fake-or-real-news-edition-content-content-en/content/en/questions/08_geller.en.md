---
uuid: 857b4ebe-a777-11e5-bf7f-feff819cdc9f
locale: en
date: 2016-03-12T00:00:00.000Z
published: true
project: "for"
slug: "question"
title: "Smashing car - Geller vid - 8"
question_title: "Is this story misinformation?"
question_subtitle: "Decide whether this item is trustworthy or not"
question_submit_message_heading: "You selected"
question_submit_message_correct: "Correct"
question_submit_message_wrong: "Wrong"
question_single_result_message_real: "It is misinformation"
question_single_result_message_fake: "It is misinformation"
question_cta_go_explanation: "Check"
question_cta_help: "Choose between the options below"
question_cta_fake: "Yes"
question_cta_real: "No"
explanation_title: "Is this story misinformation?"
explanation_subtitle: "Decide whether this item is trustworthy or not"
explanation_cta_go_stats: "See what other people thought"
stats_title: "Is this story misinformation?"
stats_subtitle: "Other people decided that the advert is not trustworthy"
stats_cta_go_again: "Next Question"
stats_cta_go_finish: "Restart Game"
items:
  - fake: true
    question_media_url: "https://www.youtube.com/watch?v=7GZEtb2C7p0"
    explanation_media_url: "https://www.youtube.com/watch?v=7GZEtb2C7p0"
    stats_media_url: "https://www.youtube.com/watch?v=7GZEtb2C7p0"
    question_title: ""
    question_text: "This video, showing men destroying a car with baseball bats, was posted on YouTube with a title that reads 'Angry immigrants attack a police car'."
    explanation_title: ""
    stats_title: ""
    click_count: 0
---
### This story can be considered misinformation!

The video was shared as evidence of so-called ‘migrant crime’ in Italy. But the video actually shows the filming of the 2015 Italian film ‘Mediterranea'. If you look closely, you can see members of the film crew holding up a microphone and a reflector.

The video was posted by anti-immigrant bloggers around the world, and has since been debunked, but it illustrates how easy it is to take video footage and present it out of context with a different headline to lead viewers to believe something other than what is actually shown in the original video.