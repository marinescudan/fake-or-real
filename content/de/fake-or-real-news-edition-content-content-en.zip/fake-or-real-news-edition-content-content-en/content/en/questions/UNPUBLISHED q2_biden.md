---
uuid: 857b5b3e-a777-11e5-bf7f-feff819cdc9f
locale: en
date: 2016-03-12T00:00:00.000Z
published: false
project: "for"
slug: "question"
title: "Exemple 1"
question_title: "Is this video fake or real?"
question_subtitle: "US Democratic politcian Joe Biden speaking at a campaign rally"
question_submit_message_heading: "You selected"
question_submit_message_correct: "Correct"
question_submit_message_wrong: "Wrong"
question_single_result_message_real: "It is real"
question_single_result_message_fake: "It is fake"
question_cta_go_explanation: "Check"
question_cta_help: "Click one of the options below!"
question_cta_fake: "Fake?"
question_cta_real: "Real?"
explanation_title: "Is This Item Fake Or Real"
explanation_subtitle: "US Democratic politician Joe Biden speaking at a campaign rally"
explanation_cta_go_stats: "See what other people thought"
stats_title: "Is This Item Fake Or Real"
stats_subtitle: "Other people decided that the advert is not trustworthy"
stats_cta_go_again: "Next Question"
stats_cta_go_finish: "Restart Game"
items:
  - fake: true
    question_media_url: "https://youtu.be/l1-6cwetV5k?t=878"
    explanation_media_url: "https://youtu.be/l1-6cwetV5k?t=878"
    stats_media_url: "https://youtu.be/l1-6cwetV5k?t=878"
    question_title: ""
    question_text: ""
    explanation_title: ""
    stats_title: ""
    click_count: 0
---
### This is a genuine video - but it is misleading

This is a genuine video of US Presidential candidate – and well known Trump critic - Joe Biden at a campaign rally apparently supporting Donald Trump.

Although this is actual footage, Joe Biden makes a mistake – which he later corrects but is edited out of the video.

“Deep fake” videos, where advanced software is used to generate lifelike videos of people, are now increasingly common. But genuine videos can also be edited to be just as misleading.