---
uuid: 1c936105-9716-489e-8364-532d436cb27d
locale: en
date: 2016-03-12T00:00:00.000Z
published: true
project: "for"
slug: "question"
title: "billgates"
question_title: "Is the image misleading?"
question_subtitle: "Decide whether this item is trustworthy or not"
question_submit_message_heading: "You selected"
question_submit_message_correct: "Correct"
question_submit_message_wrong: "Wrong"
question_single_result_message_real: "It is not misleading"
question_single_result_message_fake: "It is misleading"
question_cta_go_explanation: "Check"
question_cta_help: "Choose between the options below"
question_cta_fake: "Yes"
question_cta_real: "No"
explanation_title: "Is the image misleading?"
explanation_subtitle: "Decide whether this item is trustworthy or not"
explanation_cta_go_stats: "See what other people thought"
stats_title: "Is the image misleading?"
stats_subtitle: "Other people decided that the advert is not trustworthy"
stats_cta_go_again: "Next Question"
stats_cta_go_finish: "Restart Game"
items:
  - fake: true
    question_media_url: "https://cdn.ttc.io/s/fake-or-real-app/billgates.png"
    explanation_media_url: "https://cdn.ttc.io/s/fake-or-real-app/billgates.png"
    stats_media_url: "https://cdn.ttc.io/s/fake-or-real-app/billgates.png"
    question_title: ""
    question_text: ""
    explanation_title: ""
    stats_title: ""
    click_count: 0
---
### The image has been altered.

This image is the sub-product of the conspiracy theory that Bill Gates, through his foundation, seeks to control global human populations through vaccines. In 2020, the foundation began efforts in finding a vaccine to end the coronavirus pandemic. 
As a result, images like these have begun to resurface. 