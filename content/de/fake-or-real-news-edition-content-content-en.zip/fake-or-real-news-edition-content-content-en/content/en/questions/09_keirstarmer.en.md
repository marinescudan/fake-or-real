---
uuid: 857b4ce8-a777-11e5-bf7f-feff819cdc9f
locale: en
date: 2016-03-12T00:00:00.000Z
published: true
project: "for"
slug: "question"
title: "Starmer - 7"
question_title: "Could this video be considered misinformation?"
question_subtitle: "Decide whether this item is trustworthy or not"
question_submit_message_heading: "You selected"
question_submit_message_correct: "Correct"
question_submit_message_wrong: "Wrong"
question_single_result_message_real: "It is misinformation"
question_single_result_message_fake: "It is misinformation"
question_cta_go_explanation: "Check"
question_cta_help: "Choose between the options below"
question_cta_fake: "Yes"
question_cta_real: "No"
explanation_title: "Could this video be considered misinformation?"
explanation_subtitle: "Decide whether this item is trustworthy or not"
explanation_cta_go_stats: "See what other people thought"
stats_title: "Is this video fake or real?"
stats_subtitle: "Other people decided that the advert is not trustworthy"
stats_cta_go_again: "Next Question"
stats_cta_go_finish: "Restart Game"
items:
  - fake: true
    question_media_url: "https://youtu.be/QT2w45c6WwU"
    explanation_media_url: "https://youtu.be/QT2w45c6WwU"
    stats_media_url: "https://youtu.be/QT2w45c6WwU"
    question_title: ""
    question_text: ""
    explanation_title: ""
    stats_title: ""
    click_count: 0
---
## This can be considered misninformation

This campaign video was made by the opposing UK Conservative Party to show Labour politician Keir Starmer seemingly unable to answer a simple question about Brexit on a morning news programme.

In the actual interview Keir Stramer answered promptly; the video was edited misleadingly. Increasingly campaigns from all types of political parties are using “cheap fakes”, simple techniques like this one to misrepresent their opponents. 

On social media these campaign videos are often not checked,  and unlike with a newspaper or TV advert, there is rarely any penalty when they are found out.