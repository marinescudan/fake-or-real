---
uuid: 857b61ec-a777-11e5-bf7f-feff819cdc9f
locale: en
date: 2016-03-12T00:00:00.000Z
published: true
project: "for"
slug: "question"
title: "Exemple 1"
question_title: "Which of these politicians' tweets was removed from Twitter?"
question_subtitle: ""
question_submit_message_heading: "1 out of the 4 were removed"
question_submit_message_correct: "Correct"
question_submit_message_wrong: "Wrong"
question_single_result_message_real: "It is real"
question_single_result_message_fake: "It is fake"
question_cta_go_explanation: "Check"
question_cta_help: "Choose between 1 and 4 of the options above!"
question_cta_fake: "Fake?"
question_cta_real: "Real?"
explanation_title: "Only one of these was removed"
explanation_subtitle: ""
explanation_cta_go_stats: "See what other people thought"
stats_title: "Find the fake adverts"
stats_subtitle: "Other people decided that these adverts are not trustworthy"
stats_cta_go_again: "Next Question"
stats_cta_go_finish: "Restart Game"
items:
  - fake: false
    question_media_url: "https://cdn.ttc.io/s/fake-or-real-app/takedown1.jpg"
    explanation_media_url: "https://cdn.ttc.io/s/fake-or-real-app/takedown1.jpg"
    stats_media_url: "https://cdn.ttc.io/s/fake-or-real-app/takedown1.jpg"
    question_title: ""
    question_text: "Donald Trump's tweet to Theresa May on Islamic terrorism"
    explanation_title: ""
    stats_title: ""
    click_count: 0
  - fake: false
    question_media_url: "https://cdn.ttc.io/s/fake-or-real-app/takedown2.jpg"
    explanation_media_url: "https://cdn.ttc.io/s/fake-or-real-app/takedown2.jpg"
    stats_media_url: "https://cdn.ttc.io/s/fake-or-real-app/takedown2.jpg"
    question_title: ""
    question_text: "Italian Politican Matteo Salvini tweets about Coronavirus myths"
    explanation_title: ""
    stats_title: ""
    click_count: 0
  - fake: true
    question_media_url: "https://cdn.ttc.io/s/fake-or-real-app/takedown3.jpg"
    explanation_media_url: "https://cdn.ttc.io/s/fake-or-real-app/takedown3.jpg"
    stats_media_url: "https://cdn.ttc.io/s/fake-or-real-app/takedown3.jpg"
    question_title: ""
    question_text: "Brazilian President Jair Bolsonaro tweets a video showing factories that remained open in light of the Coronavirus health emergency, indicating that such a situation was threatening to the health of the people"
    explanation_title: ""
    stats_title: ""
    click_count: 0
  - fake: false
    question_media_url: "https://cdn.ttc.io/s/fake-or-real-app/takedown4.jpg"
    explanation_media_url: "https://cdn.ttc.io/s/fake-or-real-app/takedown4.jpg"
    stats_media_url: "https://cdn.ttc.io/s/fake-or-real-app/takedown4.jpg"
    question_title: ""
    question_text: "Australian politician Concetta Fierravanti-Wells saying bushfires were caused by arsonists"
    explanation_title: ""
    stats_title: ""
    click_count: 0
---
### All of these tweets provide false information.

However, only one of them, Bolsonaro's tweet, was taken down by Twitter, while the other tweets continue to be visible on the platform.
